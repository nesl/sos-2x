#ifndef __msp430x15x
#define __msp430x15x

/* msp430x15x.h
 *
 * mspgcc project: MSP430 device headers
 * MSP430x15x family header
 *
 * (c) 2002 by Steve Underwood <steveu@coppice.org>
 * Originally based in part on work by Texas Instruments Inc.
 *
 * $Id: msp430x15x.h,v 1.4 2004/10/05 15:44:05 coppice Exp $
 */

#include <iomacros.h>

#define __msp430_have_port1
#define __msp430_have_port2
#define __msp430_have_port3
#define __msp430_have_port4
#define __msp430_have_port5
#define __msp430_have_port6
#define __msp430_have_usart0_with_i2c
#define __msp430_have_svs_at_0x55

#include <msp430/gpio.h>
#include <msp430/usart.h>
#include <msp430/svs.h>
#include <msp430/flash.h>
#include <msp430/compa.h>
#include <msp430/timera.h>
#include <msp430/timerb.h>
#include <msp430/basic_clock.h>
#include <msp430/adc12.h>
#include <msp430/dac12.h>
#include <msp430/dma.h>

#include <msp430/common.h>

#define IE1_                0x0000  /* Interrupt Enable 1 */
sfrb(IE1,IE1_);
#define WDTIE               (1<<0)
#define OFIE                (1<<1)
#define NMIIE               (1<<4)
#define ACCVIE              (1<<5)
#define URXIE0              (1<<6)
#define UTXIE0              (1<<7)

#define IFG1_               0x0002  /* Interrupt Flag 1 */
sfrb(IFG1,IFG1_);
#define WDTIFG              (1<<0)
#define OFIFG               (1<<1)
#define NMIIFG              (1<<4)
#define URXIFG0             (1<<6)
#define UTXIFG0             (1<<7)

#define ME1_                0x0004  /* Module Enable 1 */
sfrb(ME1,ME1_);
#define URXE0               (1<<6)
#define USPIE0              (1<<6)
#define UTXE0               (1<<7)

#define DACDMA_VECTOR       0       /* 0xFFE0 DAC12/DMA */
#define PORT2_VECTOR        2       /* 0xFFE2 Port 2 */
#define PORT1_VECTOR        8       /* 0xFFE8 Port 1 */
#define TIMERA1_VECTOR      10      /* 0xFFEA Timer A CC1-2, TA */
#define TIMERA0_VECTOR      12      /* 0xFFEC Timer A CC0 */
#define ADC_VECTOR          14      /* 0xFFEE ADC */
#define USART0TX_VECTOR     16      /* 0xFFF0 USART 0 Transmit */
#define USART0RX_VECTOR     18      /* 0xFFF2 USART 0 Receive, I2C tx/rx */
#define WDT_VECTOR          20      /* 0xFFF4 Watchdog Timer */
#define COMPARATORA_VECTOR  22      /* 0xFFF6 Comparator A */
#define TIMERB1_VECTOR      24      /* 0xFFF8 Timer B CC1-2, TB */
#define TIMERB0_VECTOR      26      /* 0xFFFA Timer B CC0 */
#define NMI_VECTOR          28      /* 0xFFFC Non-maskable */ 

#define UART0TX_VECTOR      USART0TX_VECTOR
#define UART0RX_VECTOR      USART0RX_VECTOR

#endif /* #ifndef __msp430x15x */
